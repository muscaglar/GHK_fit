function [params,output] = GHK_rollings_Fit_Ani_Mono( cIDs,varargin)

R = 8.3144621; % J / mol K
F = 96485.3399; %C / mol
T = 300; %K 

switch nargin
    case 1
        maxResConc = 10000000;
        minResConc = 0.00000001;
    case 3
        maxResConc = varargin{2};
        minResConc = varargin{1};
    otherwise      
end

[aResConcs,aCapConcs,aVoltageOffsets,~,errors, ~,~, ~,std_mean_error_V] = ca_selectivity(cIDs,1,minResConc,maxResConc);
x_conc = aResConcs ./ aCapConcs;
y_v = (-1.*aVoltageOffsets)*1E-3; %V
std_mean_error_V = std_mean_error_V * 1E-3;
% Fit
close all;

F = @(P,xdata)(R*T/F).*log( ((1/P) + xdata) ./ ((1/P).*xdata + 1) );

beta = 100;
figure;
[P,resnorm,resid,exitflag,output,lambda,J] = lsqcurvefit(F,beta,x_conc,y_v);
tbl = table(x_conc',y_v');
mdl = fitnlm(tbl,F,P);

fit_RMSE = mdl.RMSE;
fit_Rsquared_Adj = mdl.Rsquared.Adjusted;
fit_Rsquared_Ord = mdl.Rsquared.Ordinary;
fit_SSE = mdl.SSE;
fit_SSR = mdl.SSR;
fit_SST = mdl.SST;
Perm_value = mdl.Coefficients.Estimate;
Perm_value_error = mdl.Coefficients.SE;

plot(x_conc,y_v,'ro');
hold on
response = F(P,x_conc);
plot(x_conc,response)
hold off

output = [x_conc',y_v',std_mean_error_V',response'];
params = [Perm_value, Perm_value_error, fit_RMSE, fit_Rsquared_Adj, fit_Rsquared_Ord, fit_SSE, fit_SSR, fit_SST];


% rng default % for reproducibility
% a = 0;
% b = 2;
% N = 250; % number of data points
% xdata = (b-a).*rand(N,1) + a;% data points
% ydata = F(0,xdata) + 0.1*((b-a).*rand(N,1) + a); % response data with noise
% 
% lb = [0];
% ub = [100];
% 
% p0 = 10;
% 
% [xfitted,errorfitted] = lsqcurvefit(F,p0,xdata,ydata,lb,ub);
% 
% problem = createOptimProblem('lsqcurvefit','x0',p0,'objective',F,...
%     'lb',lb,'ub',ub,'xdata',xdata,'ydata',ydata);
% 
% ms = MultiStart('PlotFcns',@gsplotbestf);
% [xmulti,errormulti] = run(ms,problem,100)
% 
% close all;
% figure;
% plot(x_conc,y_v,'ro');
% hold on
% plot(x_conc,F(xmulti,x_conc))
% hold off

end

