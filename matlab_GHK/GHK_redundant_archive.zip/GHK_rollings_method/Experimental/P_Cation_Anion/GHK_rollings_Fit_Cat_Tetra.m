function [params,output] = GHK_rollings_Fit_Cat_Tetra( cIDs,varargin)

switch nargin
    case 1
        maxResConc = 10000000;
        minResConc = 0.00000001;
    case 3
        maxResConc = varargin{2};
        minResConc = varargin{1};
    otherwise      
end

[aResConcs,aCapConcs,aVoltageOffsets,~,errors, ~,~, ~,std_mean_error_V] = ca_selectivity(cIDs,1,minResConc,maxResConc);
x_conc = aResConcs ./ aCapConcs;
y_v = (-1.*aVoltageOffsets)*1E-3; %V
std_mean_error_V = std_mean_error_V * 1E-3;

% Fit
F = @(P,xdata)myImplicitF(xdata,P);

beta = 100;
figure;
[P,resnorm,resid,exitflag,output,lambda,J] = lsqcurvefit(F,beta,x_conc,y_v);
tbl = table(x_conc',y_v');
mdl = fitnlm(tbl,F,P);

fit_RMSE = mdl.RMSE;
fit_Rsquared_Adj = mdl.Rsquared.Adjusted;
fit_Rsquared_Ord = mdl.Rsquared.Ordinary;
fit_SSE = mdl.SSE;
fit_SSR = mdl.SSR;
fit_SST = mdl.SST;
Perm_value = mdl.Coefficients.Estimate;
Perm_value_error = mdl.Coefficients.SE;

plot(x_conc,y_v,'ro');
hold on
response = F(P,x_conc);
plot(x_conc,response)
hold off

output = [x_conc',y_v',std_mean_error_V',response'];
params = [Perm_value, Perm_value_error, fit_RMSE, fit_Rsquared_Adj, fit_Rsquared_Ord, fit_SSE, fit_SSR, fit_SST];


% Fsumsquares = @(P)sum((F(P,x_conc)-y_v).^2);
% opts = optimoptions('fminunc','Algorithm','quasi-newton','MaxFunctionEvaluations', 10000);
% [xunc,ressquared,eflag,outputu] = fminunc(Fsumsquares,100,[],[],[],[],[],['MaxFunctionEvaluations', 10000]);
% 
% figure;
% plot(x_conc,y_v,'ro');
% hold on
% plot(x_conc,F(xunc,x_conc))
% hold off

end

