function [params,output] = ideal_GHK_rollings_Fit_Ani_Di(capConc,selec)

if strcmp(selec,'cation')
    prefix = -2;
elseif strcmp(selec,'anion')
    prefix = 1;
end

R = 8.3144621; % J / mol K
F_c = 96485.3399; %C / mol
T = 300; %K

aResConcs = [1E-5, 1E-4, 1E-3, 1E-2, 1E-1, 1, 2, 3, 4,10] ;
aCapConcs = (zeros(1,size(aResConcs,2)) ) + capConc ;
x_conc = aResConcs ./ aCapConcs;
y_v = prefix.*(R.*T ./ F_c) .* log(x_conc);

F = @(P,xdata)(R*T/F_c).*log((sqrt(8.*xdata.^2.*(1/P) + xdata.^2 + 16.*xdata.*(1/P).^2 + 2.*xdata + 8.*(1/P) + 1) + xdata - 1)./(2.*(2.*xdata.*(1/P) + 1)));
beta = 100;
figure;
[P,resnorm,resid,exitflag,output,lambda,J] = lsqcurvefit(F,beta,x_conc,y_v);
tbl = table(x_conc',y_v');

try
    mdl = fitnlm(tbl,F,P);
    fit_RMSE = mdl.RMSE;
    fit_Rsquared_Adj = mdl.Rsquared.Adjusted;
    fit_Rsquared_Ord = mdl.Rsquared.Ordinary;
    fit_SSE = mdl.SSE;
    fit_SSR = mdl.SSR;
    fit_SST = mdl.SST;
    Perm_value = mdl.Coefficients.Estimate;
    Perm_value_error = mdl.Coefficients.SE;
catch
    warning('Some error');
    fit_RMSE = 0;
    fit_Rsquared_Adj = 0;
    fit_Rsquared_Ord = 0;
    fit_SSE = 0;
    fit_SSR = 0;
    fit_SST = 0;
    Perm_value =0;
    Perm_value_error = 0;
end

response = F(P,x_conc);

output = [x_conc',y_v',response'];
params = [P, 0, fit_RMSE, fit_Rsquared_Adj, fit_Rsquared_Ord, fit_SSE, fit_SSR, fit_SST];

end

