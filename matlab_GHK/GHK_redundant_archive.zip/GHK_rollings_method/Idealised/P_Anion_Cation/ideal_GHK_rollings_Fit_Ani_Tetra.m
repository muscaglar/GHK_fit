function [params,output] = ideal_GHK_rollings_Fit_Ani_Tetra(capConc,selec)

if strcmp(selec,'cation')
    prefix = -4;
elseif strcmp(selec,'anion')
    prefix = 1;
end

R = 8.3144621; % J / mol K
F_c = 96485.3399; %C / mol
T = 300; %K 

aResConcs = [1E-5, 1E-4, 1E-3, 1E-2, 1E-1, 1,10] ;
aCapConcs = (zeros(1,size(aResConcs,2)) ) + capConc ;
x_conc = aResConcs ./ aCapConcs;
y_v = prefix.*(R.*T ./ F_c) .* log(x_conc);

xdata = x_conc;

% Fit
F = @(P,xdata)ideal_myImplicitF_ani(xdata,P);

% problem = createOptimProblem('lsqcurvefit','x0',100,'objective',F,'xdata',xdata,'lb',0,'ydata',y_v);
% ms = MultiStart('PlotFcns',@gsplotbestf);
% [xmulti,errormulti] = run(ms,problem,50);
xmulti = 10;
options = optimset('FinDiffRelStep',1e1,'Algorithm','trust-region-reflective','Display','on','MaxIter',1e100,'MaxFunEvals',1e100,'FunValCheck','on','TolFun',1e-100,'TolX',1e-100);
[P,resnorm,resid,exitflag,output,lambda,J] = lsqcurvefit(F,xmulti,x_conc,y_v,0,[],options);


% 
ci = nlparci(P,resid,'jacobian',J);


try
   % [P,resnorm,resid,exitflag,output,lambda,J] = lsqcurvefit(F,beta,x_conc,y_v,[],[],options);
   % ci = nlparci(P,resid,'jacobian',J);
catch
    warning('Model fit failed')
    P = beta;
end

try
    response = F(P,x_conc);
catch
    warning('Model fit failed')
    response = x_conc .* 0 ;
end

output = [x_conc',y_v',response'];
params = [P, 0, 0, 0, 0, 0, 0, 0];
%params = [P, 0, fit_RMSE, fit_Rsquared_Adj, fit_Rsquared_Ord, fit_SSE, fit_SSR, fit_SST];



end

