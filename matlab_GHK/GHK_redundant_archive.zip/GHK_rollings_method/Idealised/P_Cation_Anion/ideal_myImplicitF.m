function yout = ideal_myImplicitF(xdata, B)
    P=double(B(1));
    T=300;
    F=96485.3329;
    R=8.314;
    yout = zeros(size(xdata));
    opt = optimset('display','off','MaxFunEvals', 100000);
    for i=1:length(xdata)
        yout(i) = fsolve(@(V)(((exp((F.*V)./(R.*T))+exp((2.*F.*V)./(R.*T))+exp((3.*F.*V)./(R.*T))+1).*(exp((F.*V)./(R.*T))-xdata(i)))./(4-4.*xdata(i).*exp((4.*F.*V)./(R.*T))))-P,10,opt);
    end
end