concs = [0.0001,0.001, 0.01, 0.1, 1,10];


params_an_ancat = [];
params_an_catan = [];
params_cat_ancat = [];
params_cat_catan = [];

output_an_ancat = [];
output_an_catan = [];
output_cat_ancat = [];
output_cat_catan = [];

% %MgCl2 - Mg 2+, Cl 1-
% for i = concs
%     
% [params_an_ancat_temp,output_an_ancat_temp] = ideal_GHK_rollings_Fit_Ani_Di(i,'anion');
% [params_an_catan_temp,output_an_catan_temp] = ideal_GHK_rollings_Fit_Cat_Di(i,'anion');
% 
% 
% [params_cat_ancat_temp,output_cat_ancat_temp] = ideal_GHK_rollings_Fit_Ani_Di(i,'cation');
% [params_cat_catan_temp,output_cat_catan_temp] = ideal_GHK_rollings_Fit_Cat_Di(i,'cation');
% 
% close all;
% 
% params_an_ancat = [params_an_ancat; [i, params_an_ancat_temp]];
% params_an_catan = [params_an_catan; [i, params_an_catan_temp]];
% params_cat_ancat = [params_cat_ancat; [i, params_cat_ancat_temp]];
% params_cat_catan = [params_cat_catan; [i, params_cat_catan_temp]];
% 
% output_an_ancat = [output_an_ancat; output_an_ancat_temp];
% output_an_catan = [output_an_catan;output_an_catan_temp];
% output_cat_ancat = [output_cat_ancat;output_cat_ancat_temp];
% output_cat_catan = [output_cat_catan;output_cat_catan_temp];
% 
% end


%CeCl3 - Ce 3+, Cl 1-
% for i = concs
%     
% [params_an_ancat_temp,output_an_ancat_temp] = ideal_GHK_rollings_Fit_Ani_Tri(i,'anion');
% [params_an_catan_temp,output_an_catan_temp] = ideal_GHK_rollings_Fit_Cat_Tri(i,'anion');
% 
% 
% [params_cat_ancat_temp,output_cat_ancat_temp] = ideal_GHK_rollings_Fit_Ani_Tri(i,'cation');
% [params_cat_catan_temp,output_cat_catan_temp] = ideal_GHK_rollings_Fit_Cat_Tri(i,'cation');
% 
% close all;
% 
% params_an_ancat = [params_an_ancat; [i, params_an_ancat_temp]];
% params_an_catan = [params_an_catan; [i, params_an_catan_temp]];
% params_cat_ancat = [params_cat_ancat; [i, params_cat_ancat_temp]];
% params_cat_catan = [params_cat_catan; [i, params_cat_catan_temp]];
% 
% output_an_ancat = [output_an_ancat; output_an_ancat_temp];
% output_an_catan = [output_an_catan;output_an_catan_temp];
% output_cat_ancat = [output_cat_ancat;output_cat_ancat_temp];
% output_cat_catan = [output_cat_catan;output_cat_catan_temp];
% 
% end


%HfCl4 - Hf 4+, Cl 1-
for i = concs
    
[params_an_ancat_temp,output_an_ancat_temp] = ideal_GHK_rollings_Fit_Ani_Tetra(i,'anion');
% [params_an_catan_temp,output_an_catan_temp] = ideal_GHK_rollings_Fit_Cat_Tetra(i,'anion');
% 
% 
% [params_cat_ancat_temp,output_cat_ancat_temp] = ideal_GHK_rollings_Fit_Ani_Tetra(i,'cation');
% [params_cat_catan_temp,output_cat_catan_temp] = ideal_GHK_rollings_Fit_Cat_Tetra(i,'cation');

close all;

  params_an_ancat = [params_an_ancat; [i, params_an_ancat_temp]];
% params_an_catan = [params_an_catan; [i, params_an_catan_temp]];
% params_cat_ancat = [params_cat_ancat; [i, params_cat_ancat_temp]];
% params_cat_catan = [params_cat_catan; [i, params_cat_catan_temp]];
% 
  output_an_ancat = [output_an_ancat; output_an_ancat_temp];
% output_an_catan = [output_an_catan;output_an_catan_temp];
% output_cat_ancat = [output_cat_ancat;output_cat_ancat_temp];
% output_cat_catan = [output_cat_catan;output_cat_catan_temp];
% 
% clear output_an_ancat_temp output_an_catan_temp output_cat_ancat_temp output_cat_catan_temp params_an_ancat_temp params_an_catan_temp params_cat_ancat_temp params_cat_catan_temp

end

% %K3PO4 - K 1+, PO4 3-
% for i = concs
%     
% [params_an_ancat_temp,output_an_ancat_temp] = ideal_GHK_rollings_Fit_Ani_K3PO4(i,'anion');
% [params_an_catan_temp,output_an_catan_temp] = ideal_GHK_rollings_Fit_K3PO4(i,'anion');
% 
% 
% [params_cat_ancat_temp,output_cat_ancat_temp] = ideal_GHK_rollings_Fit_Ani_K3PO4(i,'cation');
% [params_cat_catan_temp,output_cat_catan_temp] = ideal_GHK_rollings_Fit_K3PO4(i,'cation');
% 
% close all;
% 
% params_an_ancat = [params_an_ancat; [i, real(params_an_ancat_temp)]];
% params_an_catan = [params_an_catan; [i, real(params_an_catan_temp)]];
% params_cat_ancat = [params_cat_ancat; [i, real(params_cat_ancat_temp)]];
% params_cat_catan = [params_cat_catan; [i, real(params_cat_catan_temp)]];
% 
% output_an_ancat = [output_an_ancat; real(output_an_ancat_temp)];
% output_an_catan = [output_an_catan; real(output_an_catan_temp)];
% output_cat_ancat = [output_cat_ancat; real(output_cat_ancat_temp)];
% output_cat_catan = [output_cat_catan; real(output_cat_catan_temp)];
% 
% clear output_an_ancat_temp output_an_catan_temp output_cat_ancat_temp output_cat_catan_temp params_an_ancat_temp params_an_catan_temp params_cat_ancat_temp params_cat_catan_temp
% 
% end
